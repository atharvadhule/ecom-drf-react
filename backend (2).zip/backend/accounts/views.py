from rest_framework.response import Response
from rest_framework.views import APIView


class CurrentUserView(APIView):
    def get(self, request):
        return Response({"message": "Authentication has been removed."})