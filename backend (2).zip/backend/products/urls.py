from django.urls import path

from .views import ProductDetailView, ProductListCreateView

urlpatterns = [
    path("", ProductListCreateView.as_view(), name="product-list"),
    path("<int:pk>/", ProductDetailView.as_view(), name="product-detail"),
    # path("<int:pk>", ProductDetailView.as_view(), name="product-detail-no-slash"),
]
