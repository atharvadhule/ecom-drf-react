from django.contrib.auth import get_user_model
from django.urls import reverse
from rest_framework.test import APITestCase


class CurrentUserViewTests(APITestCase):
    def setUp(self):
        self.username = "jwt-user"
        self.password = "test-password"
        self.user = get_user_model().objects.create_user(
            username=self.username,
            password=self.password,
        )

    def test_requires_authentication(self):
        response = self.client.get(reverse("current_user"))

        self.assertEqual(response.status_code, 401)

    def test_returns_authenticated_user_details(self):
        token_response = self.client.post(
            reverse("token_obtain_pair"),
            {"username": self.username, "password": self.password},
            format="json",
        )
        self.assertEqual(token_response.status_code, 200)

        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {token_response.data['access']}"
        )
        response = self.client.get(reverse("current_user"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.data,
            {"id": self.user.id, "username": self.username},
        )
